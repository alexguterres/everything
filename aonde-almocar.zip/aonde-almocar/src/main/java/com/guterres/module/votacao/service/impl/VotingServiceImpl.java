package com.guterres.module.votacao.service.impl;

import com.guterres.module.votacao.domain.dto.VotingResponse;
import com.guterres.module.votacao.service.VotingService;

public class VotingServiceImpl implements VotingService{

	@Override
	public VotingResponse vote(Long idUsuario, Long idRestaurent) {
		return null;
	}
	

}
