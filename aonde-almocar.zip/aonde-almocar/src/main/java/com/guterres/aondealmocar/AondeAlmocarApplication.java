package com.guterres.aondealmocar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AondeAlmocarApplication {

	public static void main(String[] args) {
		SpringApplication.run(AondeAlmocarApplication.class, args);
	}
}
